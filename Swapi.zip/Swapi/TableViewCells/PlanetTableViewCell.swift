//
//  PlanetInformation.swift
//  Swapi
//
//  Created by mac on 2020/05/15.
//  Copyright © 2020 mac. All rights reserved.
//

import Foundation

import UIKit

class PlanetTableViewCell : UITableViewCell{
    
  @IBOutlet weak var palentNameLabel: UILabel!
    @IBOutlet weak var planetRotationPeriodLabel: UILabel!
    @IBOutlet weak var planetDiameterLabel: UILabel!
    @IBOutlet weak var planetClimateLabel: UILabel!
    @IBOutlet weak var planetPopulationLabel: UILabel!

}

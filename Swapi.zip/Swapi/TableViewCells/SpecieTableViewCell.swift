//
//  SpecieCollectionViewCell.swift
//  Swapi
//
//  Created by mac on 2020/05/15.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class SpecieTableViewCell: UITableViewCell {
    @IBOutlet weak var specieNameLabel: UILabel!
     @IBOutlet weak var specieClassificationLabel: UILabel!
     @IBOutlet weak var specieDesignationLabel: UILabel!
     @IBOutlet weak var aspecieAverageHeightLabel: UILabel!
     @IBOutlet weak var specieLanguageLabel: UILabel!
}

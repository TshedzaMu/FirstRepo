//
//  SpecieCollectionViewCell.swift
//  Swapi
//
//  Created by mac on 2020/05/15.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class SpecieTableViewCell: UITableViewCell {
    let name:String = ""
    let classification:String = ""
    let designation:String = ""
    let average_height:Int = 0
    let language: String = ""
}

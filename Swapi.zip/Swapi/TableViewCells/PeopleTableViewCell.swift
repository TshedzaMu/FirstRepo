//
//  PeopleTableViewCell.swift
//  Swapi
//
//  Created by mac on 2020/05/17.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class PeopleTableViewCell: UITableViewCell {

    @IBOutlet weak var peopleNameLabel: UILabel!
    @IBOutlet weak var peopleHeightLabel: UILabel!
    @IBOutlet weak var peopleMassLabel: UILabel!
    @IBOutlet weak var peopleGenderLabel: UILabel!
    @IBOutlet weak var peopleNirthyearLabel: UILabel!
    
    
    
}

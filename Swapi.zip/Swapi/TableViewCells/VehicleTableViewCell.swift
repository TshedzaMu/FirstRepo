//
//  VehicleCollectionViewCell.swift
//  Swapi
//
//  Created by mac on 2020/05/15.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class VehicleTableViewCell: UITableViewCell {
    
     @IBOutlet weak var vehicleNameLabel: UILabel!
     @IBOutlet weak var vehicleManufucturerLabel: UILabel!
     @IBOutlet weak var vehicleModelLabel: UILabel!
     @IBOutlet weak var vehicleCostLabel: UILabel!
     @IBOutlet weak var vehicleNumberOfCrewLabel: UILabel!
    
    
}

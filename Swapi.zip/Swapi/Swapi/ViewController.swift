//
//  ViewController.swift
//  Swapi
//
//  Created by mac on 2020/05/14.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource,UITableViewDelegate {
  
    @IBOutlet weak var starWarsInformationTableView: UITableView!
    
    var people = [PeopleData]()
    var planets = [PlanetData]()
    var spaceships = [SpaceshipData]()
    var vehicles = [VehicleData]()
    var films = [FilmData]()
    var species = [SpecieData]()
    
    lazy var informationToDisplay = 0
    
    override func viewDidLoad() {
           super.viewDidLoad()
          
           starWarsInformationTableView.delegate = self
           starWarsInformationTableView.dataSource = self
        
             getData(){
                print("Done")
                print("size",self.people.count)
             }
         
           
       }
       
    
    @IBAction func searchSegment(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
        case 0:
           print("Planets")
            informationToDisplay = 0
        case 1:
            print("ships")
            informationToDisplay = 1
        case 2:
           print("vehicles")
            informationToDisplay = 2
        case 3:
           print("people")
           informationToDisplay = 3
        case 4:
           print("films")
            informationToDisplay = 4
           
        default:
            print("Species")
            informationToDisplay = 5
            
            
        }
        starWarsInformationTableView.reloadData()
        
        
    }
    
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
      }
      
      func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell: UITableViewCell!
        
        if informationToDisplay == 0
        {
            cell = tableView.dequeueReusableCell(withIdentifier: "CID_PlanetCell", for: indexPath) as! PlanetTableViewCell
            
            
            
        } else if informationToDisplay == 1
        {
             cell = tableView.dequeueReusableCell(withIdentifier: "CID_SpaceshipCell", for: indexPath) as! SpaceshipTableViewCell
        }else if informationToDisplay == 2
        {
             cell = tableView.dequeueReusableCell(withIdentifier: "CID_VehicleCell", for: indexPath) as! VehicleTableViewCell
        }
        else if informationToDisplay == 3
        {
             cell = tableView.dequeueReusableCell(withIdentifier: "CID_PeopleCell", for: indexPath) as! PeopleTableViewCell
             // cell.PeopleNameLabel.text = "Tshedza"
     
            
            
    
            
        }else if informationToDisplay == 4
        {
             cell = tableView.dequeueReusableCell(withIdentifier: "CID_FilmCell", for: indexPath) as! FilmTableViewCell
            
        
            
        }else if informationToDisplay == 5
        {
             cell = tableView.dequeueReusableCell(withIdentifier: "CID_SpecieCell", for: indexPath) as! SpaceshipTableViewCell
        }
        
        return cell
        
      }
    
    

    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        var cellHeight = CGFloat()
              
              if informationToDisplay == 0 {
                cellHeight = 150
              } else if informationToDisplay == 1 {
                  cellHeight = 150
              } else if informationToDisplay == 2 {
                  cellHeight = 150
              } else if informationToDisplay == 3 {
                cellHeight = 150
              } else if informationToDisplay == 4 {
                   cellHeight = 150
              } else if informationToDisplay == 5 {
                  cellHeight = 150
              }
                return cellHeight

    }
    
    
    func getData(completed: @escaping () ->())  {

               let url = URL(string: "https://swapi.dev/api/people")
               var peopleData = [PeopleData]()

               let sessionCongfig = URLSession.shared
               let task: Void = sessionCongfig.dataTask(with: url!) { (data, response, error) in
               if let data = data {
                      print(data)
           //            print(response) // Response even return the URL that was called
                       do {
                           // JSON Parsing
                           let jsonData = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
                           var userDataArr = jsonData?["results"] as!  [[String: Any]]

                         //  print(userDataArr)
                           for jsonDetailData in userDataArr {
                               DispatchQueue.main.async {
                                   completed()
                                   
                                   print(jsonDetailData.count)
                                   let name = jsonDetailData["name"] as! String
                                   let height = jsonDetailData["height"] as! String
                                   let  mass = jsonDetailData["mass"] as! String
                                   let tempData = PeopleData(name: name, height: height, mass: mass)
                                   peopleData.append(tempData)
                                   print("tempdata",tempData)
                               }

                           }

                       } catch {
                         //  print(error)
                       }
                   }
               }.resume()

       }
       

       
    
    
    
}


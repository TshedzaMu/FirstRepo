//
//  PeopleTableViewCell.swift
//  Swapi
//
//  Created by mac on 2020/05/17.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class PeopleTableViewCell: UITableViewCell {

    @IBOutlet weak var PeopleNameLabel: UILabel!
    
    @IBOutlet weak var PeopleHeightLabel: UILabel!
    
    
    @IBOutlet weak var PeopleMassLabel: UILabel!
    
    
    @IBOutlet weak var peopleGenderLabel: UILabel!
    
    @IBOutlet weak var peopleNirthyearLabel: UILabel!
    
    
    
}

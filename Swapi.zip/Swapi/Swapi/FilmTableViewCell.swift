//
//  FilmCollectionViewCell.swift
//  Swapi
//
//  Created by mac on 2020/05/15.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class FilmTableViewCell: UITableViewCell {
    
    let tittle:String = ""
    let episode_id:Int = 0
    let director:String = ""
    let producer:String = ""
}

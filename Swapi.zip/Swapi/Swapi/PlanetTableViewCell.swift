//
//  PlanetInformation.swift
//  Swapi
//
//  Created by mac on 2020/05/15.
//  Copyright © 2020 mac. All rights reserved.
//

import Foundation

import UIKit

class PlanetTableViewCell : UITableViewCell{
    
    
    
    
    let  name: String = ""
    let  rotation_Period: String = ""
    let  diameter: Int = 0
    let  climate: String = ""
    let  population: Int = 0

}

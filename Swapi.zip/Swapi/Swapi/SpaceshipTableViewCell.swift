//
//  SpaceshipCollectionViewCell.swift
//  Swapi
//
//  Created by mac on 2020/05/15.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class SpaceshipTableViewCell: UITableViewCell {
    let name: String = ""
    let manufucturer: String = ""
    let passengers: Int = 0
    let startship_class: String = ""
    
}

//
//  PeopleInformation.swift
//  Swapi
//
//  Created by mac on 2020/05/15.
//  Copyright © 2020 mac. All rights reserved.
//

import Foundation

struct PeopleDataResults:Codable {
    var results: [PeopleData]
}


struct PeopleData: Codable {
    
    var name: String
    var height: String
    var mass: String
}

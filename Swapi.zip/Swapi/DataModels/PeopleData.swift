//
//  PeopleInformation.swift
//  Swapi
//
//  Created by mac on 2020/05/15.
//  Copyright © 2020 mac. All rights reserved.
//

import Foundation

struct PeopleData{
    
    var name: String
    var height: String
    var mass: String
    var gender:String
    var birthYear:String
}

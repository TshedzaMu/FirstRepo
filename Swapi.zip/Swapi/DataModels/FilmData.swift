//
//  FilmData.swift
//  Swapi
//
//  Created by mac on 2020/05/15.
//  Copyright © 2020 mac. All rights reserved.
//

import Foundation

struct FilmData:Codable {
    var title:String
    var episode_id:Int
    var director:String
    var producer:String
}

//
//  VehicleData.swift
//  Swapi
//
//  Created by mac on 2020/05/15.
//  Copyright © 2020 mac. All rights reserved.
//

import Foundation

struct VehicleData: Codable{
    var name:String
    var model:String
    var manufucturer:String?
    var cost_in_credits:String?
    var crew:String?
}

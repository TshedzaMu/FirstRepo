//
//  AppConstant.swift
//  Swapi
//
//  Created by mac on 2020/05/20.
//  Copyright © 2020 mac. All rights reserved.
//

import Foundation


enum SelectedSegment:Int {
    case starWarsPlanets = 0
    case starWarsSpaceships
    case starWarsVehicles
    case starWarspeople
    case starWarsFilms
    case starWarsSpecies
}


let ACTIVITY_INDICATOR_TAG = 001

